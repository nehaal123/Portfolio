package assignment2;

//Entecott, Nicholas 101090483
//Shaikh, Nehaal 101095479
public class Account {
    public long accountNum;
    public double balance;
    public String owner;
    
    public Account(long accNum, double Balance, String name){
    
        accountNum = accNum;
        balance = Balance;
        owner = name;
    }
    
    public Boolean withdraw(double amount){
        if(amount > balance){
            System.out.println("Not enough funds!");
            return false;
        }
        else{
            balance -= amount;
            System.out.println("Amount withdrawn.");
            return true;
        }
    }
    
    public void deposit(double amt){
        balance += amt;
        System.out.println("Deposited: " + amt);
    }
    
    public boolean transfer(Account transferee, double amount){
        if(withdraw(amount)==true){
            transferee.deposit(amount);
            return true;
        }
        else{
            System.out.println("Error: No transfer done.");
            return false;
        }
    }
    
    public String toString(){
        String s = "Account Number: " + accountNum + " Balance: " + balance + " Account Owner: " + owner;
        System.out.println(s);
        return s;   
    }
    
    public long getAccountNumber(){
        return accountNum;
    }
    
    public double getBalance(){
        return balance;
    }
    public String getOwner(){
        return owner;
    }
}

