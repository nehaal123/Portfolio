
package assignment2;
import assignment2.Account;

//Entecott, Nicholas 101090483
//Shaikh, Nehaal 101095479
public class Bank
{
    private int numAccounts ;
    private int maxAccounts;
    private Account [] accountList ;
    
    public Bank(int numAcc, int maxAcc)
    {
        numAccounts = numAcc;
        maxAccounts= maxAcc;
        accountList= new Account[maxAcc];
    }
    
    public boolean addAccounts(long accNum, double Balance, String name){
        if(numAccounts < maxAccounts){
            accountList[numAccounts] = new Account(accNum, Balance, name);
            numAccounts++;
            return true;
        }
        else{
            System.out.println("Error: Account creation failed.");
            return false;
        }
    }
    
    public String printAccounts(){
        String errorReturn = "Error: No accounts found";
        String s="";
        for(int i = 0; i < numAccounts;i++){
           s= s+accountList[i].toString()+"\n";
           
        }
        return s;
    }
        
     public int findAccount(long accountNum){
        for(int i = 0; i < accountList.length; i++){
            if(accountList[i].getAccountNumber() == accountNum){
                return i;
            }
        }
        return -1;
    }
     
     public boolean depositAccount(long accNum, double amount){
        int x = findAccount(accNum);
         if(x != -1){
             accountList[x].deposit(amount);
             return true;
        }
         return false;
    }
    
    public boolean withdrawAccount(long accNum, double amount){
        int x = findAccount(accNum);
        if(x != -1){
            accountList[x].withdraw(amount);
            return true;
        }
        else
            return false;
    }

    public boolean transfer(long accNumFrom,long accNumTo, double amount){
        int x = findAccount(accNumFrom);
        int y = findAccount(accNumTo);
        
        if (x!=-1 && y!=-1){
            accountList[findAccount(accNumFrom)].transfer(accountList[findAccount(accNumTo)], amount);
            return true;
        }
        else{
            System.out.println("One or both of the ccount(s) do not exist.");
            return false;
        }

    }  
     
}