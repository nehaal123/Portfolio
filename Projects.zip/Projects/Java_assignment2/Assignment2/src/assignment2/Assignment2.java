package assignment2;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.scene.layout.*;

//Entecott, Nicholas 101090483
//Shaikh, Nehaal 101095479
public class Assignment2 extends Application implements EventHandler<ActionEvent> {
    private  Scene home,addScene,depositScene,withdrawScene,listScene,transferScene;
    Stage window;  // represents main Stage globally
    Button btnAddMenu,btnDepositMenu,btnWithdrawMenu,btnTransferMenu,btnListMenu,btnAdd,btnHome,btnListHome,btndep,btnbck,btnwith, btnwbck, btnTransfer, btnTbck;
    TextField custName,custAccNum,custBalance,tfdep,tfdepAccNum,tfwithAccNum,tfwithAmt,tfFAccNum, tfTAccNum, tfTAmt;
    TextArea accountList;
    Bank bank = new Bank(0, 1000);
    public void init(){
        
    }
    
    public void start(Stage primaryStage){
        window = primaryStage;
        // setting up Home Scene
        Label lblHomeMenu = new Label("Welcome to Trusty Bank. Please select an option from below");
        btnAddMenu = new Button("Add");btnAddMenu.setOnAction(this);btnAddMenu.setMaxWidth(Double.MAX_VALUE);
        btnDepositMenu = new Button("Deposit");btnDepositMenu.setOnAction(this);btnDepositMenu.setMaxWidth(Double.MAX_VALUE);
        btnWithdrawMenu = new Button("Withdraw");btnWithdrawMenu.setOnAction(this);btnWithdrawMenu.setMaxWidth(Double.MAX_VALUE);
        btnTransferMenu = new Button("Transfer");btnTransferMenu.setOnAction(this);btnTransferMenu.setMaxWidth(Double.MAX_VALUE);
        btnListMenu = new Button("List");btnListMenu.setOnAction(this);btnListMenu.setMaxWidth(Double.MAX_VALUE);
        VBox homeLayout = new VBox();
        homeLayout.setAlignment(Pos.CENTER);
        homeLayout.getChildren().addAll(lblHomeMenu,btnAddMenu,btnDepositMenu,btnWithdrawMenu,btnTransferMenu,btnListMenu);
        home = new Scene(homeLayout,500,500);
        
        // setting up Add Scene
        Label lblName =new Label("Name:");
        custName = new TextField();
        Label lblAccNum =new Label("Account Number:");
        custAccNum=new TextField();
        Label lblBalance =new Label("Balance:");
        custBalance = new TextField();
        btnAdd = new Button("Add Account");btnAdd.setOnAction(this);
        btnHome = new Button("Back");btnHome.setOnAction(this);
        VBox addLayout =new VBox();
        addLayout.getChildren().addAll(lblName,custName,lblAccNum,custAccNum,lblBalance,custBalance,btnAdd,btnHome);
        addScene = new Scene(addLayout,500,500);
        
        // setting up List Scene
        Label lblShow = new Label("List of accounts...");
        accountList = new TextArea();
        btnListHome = new Button("Back");btnListHome.setOnAction(this);
        VBox listLayout =new VBox();
        listLayout.getChildren().addAll(lblShow,accountList,btnListHome);
        listScene = new Scene (listLayout,500,500); 
        
        //setting up deposit
        Label lblacc = new Label("Enter Account Number: ");
        tfdepAccNum = new TextField();
        Label lbldep = new Label("Enter deposit amount: ");
        tfdep = new TextField();
        btndep = new Button("Deposit");btndep.setOnAction(this); 
        btnbck = new Button("Back");btnbck.setOnAction(this);
        VBox depLayout = new VBox();
        depLayout.getChildren().addAll(lblacc, tfdepAccNum, lbldep, tfdep, btndep, btnbck);
        depositScene = new Scene (depLayout, 500, 500);
        
        //setting up withdraw
        Label lblAcc = new Label("Enter Account Number: ");
        tfwithAccNum = new TextField();
        Label lblwith = new Label("Enter Withdrawal Amount: ");
        tfwithAmt = new TextField();
        btnwith = new Button("Withdraw");btnwith.setOnAction(this);
        btnwbck = new Button("Back");btnwbck.setOnAction(this);
        VBox withLayout = new VBox();
        withLayout.getChildren().addAll(lblAcc, tfwithAccNum, lblwith, tfwithAmt, btnwith, btnwbck);
        withdrawScene = new Scene (withLayout, 500, 500);
         
        //setting up transfer
        Label lblFAccNum = new Label("From Account Number: ");
        tfFAccNum = new TextField();
        Label lblTAccNum = new Label("To Account Number: ");
        tfTAccNum = new TextField();
        Label lblTAmt = new Label("Transfer Amount: ");
        tfTAmt = new TextField();
        btnTransfer = new Button("Transfer");btnTransfer.setOnAction(this);
        btnTbck = new Button("Back");btnTbck.setOnAction(this);
        VBox transferLayout = new VBox();
        transferLayout.getChildren().addAll(lblFAccNum, tfFAccNum, lblTAccNum, tfTAccNum, lblTAmt, tfTAmt, btnTransfer, btnTbck);
        transferScene = new Scene (transferLayout, 500, 500);
        
        window.setScene(home);
        window.show();
    }
    
    public void stop(){
        
    }
    
    
    public void handle(ActionEvent e){
        
        if (e.getSource()==btnAddMenu){
            System.out.println("add Menu btn pressed (on menu scene)");
            window.setScene(addScene);          
        }
        if(e.getSource()==btnAdd){
            bank.addAccounts(Long.valueOf(custAccNum.getText()), Double.valueOf(custBalance.getText()), custName.getText());
            System.out.println("Account added.");
            window.setScene(home);
        }
        if(e.getSource()==btnDepositMenu){  
            window.setScene(depositScene);
        }
        if(e.getSource()==btndep){
            bank.depositAccount(Long.valueOf(tfdepAccNum.getText()), Double.valueOf(tfdep.getText()));
            window.setScene(home);
        }
        if(e.getSource() == btnWithdrawMenu){
            window.setScene(withdrawScene);
        }
        if(e.getSource()== btnTransferMenu){
            window.setScene(transferScene);
        }
        if(e.getSource()==btnwith){
            bank.withdrawAccount(Long.valueOf(tfwithAccNum.getText()), Double.valueOf(tfwithAmt.getText()));
            window.setScene(home);
        }
        if(e.getSource()==btnbck){
            window.setScene(home);
        }
        if(e.getSource() == btnwbck){
            window.setScene(home);
        }
        if(e.getSource()==btnTransfer){
            bank.transfer(Long.valueOf(tfFAccNum.getText()), Long.valueOf(tfTAccNum.getText()), Double.valueOf(tfTAmt.getText()));
            window.setScene(home);
        }
        if(e.getSource()==btnTbck){
            window.setScene(home);
        }
        if (e.getSource()==btnListMenu){
            window.setScene(listScene);
            accountList.setText("****Begin Report****\n" +bank.printAccounts() + "****End Report****");          
        }
        if (e.getSource()==btnHome||e.getSource()==btnListHome){
            window.setScene(home);
        }
        
    }
    
    public static void main(String[] args) {
      launch(args);
    }
    
}
