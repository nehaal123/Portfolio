export class Video {
    title: string;
    rating: string;
    length: string;
    genre: string;
    director: string
}
