<?php
function dropdownLabNum(){
    $serverName = "108.163.161.66";
    $connection = new mysqli( $serverName, "f7103097_default", "default", "f7103097_lab_software");

    if($connection->connect_error){
        die("Connection to database unable to complete: ".$connection->connect_error);
    }

    try{
        $sql = "SELECT DISTINCT lab_num FROM lab_software;";
        $result = $connection->query($sql);

        echo "<form method='GET' action=''>";
        echo "Room: <select name='chooseLab' onchange='form.submit()'>";
        echo "<option name='' value=''>Select a lab room</option>";
        foreach($result as $item){
            foreach($item as $value){
                echo "<option name=$value value=$value>".$value."</option>";
            }
        }
        echo "</select></form>";
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }
    finally{
        $connection->close();
    }
}
function dropdownSoftware(){
    $serverName = "108.163.161.66";
    $connection = new mysqli( $serverName, "f7103097_default", "default", "f7103097_lab_software");

    if($connection->connect_error){
        die("Connection to database unable to complete: ".$connection->connect_error);
    }

    try{
        $sql = "SELECT DISTINCT software_name FROM lab_software;";
        $result = $connection->query($sql);

        echo "<form method='GET' action=''>";
        echo "Room: <select name='chooseSoftware' onchange='form.submit()'>";
        echo "<option name='' value=''>Select an available software</option>";
        foreach($result as $item){
            foreach($item as $value){
                echo "<option name=$value value=$value>".$value."</option>";
            }
        }
        echo "</select></form>";
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }
    finally{
        $connection->close();
    }
}
?>