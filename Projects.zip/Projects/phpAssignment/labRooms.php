<head>
    <meta charset="UTF-8">
    <meta name="author", content="Entecott, Nicholas; Haberle, Ryan; Murphy, Patrick; Shaikh, Nehaal">
    <meta name="description" content="[placehold] is a website for managing George Brown College computer lab software.">
    <meta name="keywords" content="George Brown College, GBC, Computer Labs, Software">
    <title>Lab Rooms</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="gbcCSS.css">
</head>

<body>

<header>
    <h1><a href="index.html">George Brown College</a></h1>
    <h2>Lab Software Repository/Lab Rooms</h2>
    <div id="position-left">
    <form method="post" action="softwareRequest.php">
        <input type="submit" class="btn btn-primary" value="SOFTWARE REQUEST">
    </form>
    <form method="post" action="adminLogin.php">
        <input type="submit" class="btn btn-primary" value="ADMIN LOGIN">
    </form>
    </div>
    <div>
        <form method="post" action="softwareAvailable.php">
            <input type="submit" class="btn btn-primary" value="SOFTWARE AVAILABLE">
        </form>
        <form method="post" action="labRooms.php">
            <input type="submit" class="btn btn-primary" value="LAB ROOMS">
        </form>
    </div>
</header>
<hr>

<?php
include 'dropdowns.php';
dropdownLabNum();

include 'userFunctions.php';
if(isset($_GET['chooseLab'])){
    labNumSearch(@$_GET['chooseLab']);
}
?>

</body>
</html>