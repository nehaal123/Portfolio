<?php
function adminLogin($username, $password){
    $serverName = "108.163.161.66";
    $connection = new mysqli( $serverName, $username, $password, "f7103097_lab_software");

    if($connection->connect_error){
        die("Connection to database unable to complete: ".$connection->connect_error);
    }
    else{
        echo "<script language=\"javascript\" type=\"text/javascript\">
               window.setTimeout('window.location=\"adminPage.php\"; ',1000);
               </script>";
    }
}