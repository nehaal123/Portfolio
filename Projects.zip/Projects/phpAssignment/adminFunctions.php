<?php
function displayRequests(){
    $serverName = "108.163.161.66";
    $connection = new mysqli($serverName, "f7103097_admin", "admin", "f7103097_lab_software");

    if($connection->connect_error){
        die("Connection to database unable to complete: ".$connection->connect_error);
    }

    try{
        $sql = "SELECT * FROM requests";
        $result = $connection->query($sql);

        if($result->num_rows > 0){
            echo "<table><tr><th>Lab Number</th>
                  <th>Software Name</th>
                  <th>Software Version</th>
                  <th>Notes</th></tr>";
            foreach($result as $item){
                $id = $item['id'];
                echo "<tr><td>".$item['lab_num']."</td><td>".$item['software_name']."</td><td>".$item['software_version'].
                    "</td><td>".$item['notes']."</td><td>".$item['last_updated']."</td>
                      <td><a href='?run=delete&table=requests&id=$id'>Delete</td></tr>";
            }
            echo "</table>";
        }
        else{
            echo "No results.";
        }
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }
    finally{
        $connection->close();
    }
}
function displaySoftware(){
    $serverName = "108.163.161.66";
    $connection = new mysqli( $serverName, "f7103097_admin", "admin", "f7103097_lab_software");

    if($connection->connect_error){
        die("Connection to database unable to complete: ".$connection->connect_error);
    }

    try{
        $sql = "SELECT * FROM lab_software";
        $result = $connection->query($sql);

        if($result->num_rows > 0){
            echo "<table><tr><th>Lab Num</th><th>Software Version</th></tr>";
            foreach($result as $item){
                $id = $item['id'];
                echo "<tr><td>".$item['lab_num']."</td><td>".$item['software_name']."</td><td>".$item['software_version'].
                    "</td><td>".$item['last_updated']."</td><td><a href='?run=delete&table=lab_software&id=$id'";
                echo "<a href='?run=delete&table=lab_software&id=$id' onclick=\"return confirm('Are you sure?');\">Delete</a></td></tr>";
            }
            echo "</table>";
        }
        else{
            echo "No results.";
        }
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }
    finally{
        $connection->close();
    }
}
function addSoftware($labNum, $softwareName, $softwareVersion){
    $serverName = "108.163.161.66";
    $connection = new mysqli($serverName, "f7103097_admin", "admin", "f7103097_lab_software");

    if($connection->connect_error){
        die("Connection to database unable to complete: ".$connection->connect_error);
    }

    try{
        $sql = "INSERT INTO `lab_software` (`lab_num`, `software_name`, `software_version`, `last_updated`)
                VALUES ('$labNum', '$softwareName', '$softwareVersion', CURRENT_TIMESTAMP);";
        $connection->query($sql);
        echo "Software added.";
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }
    finally{
        $connection->close();
    }
}
function deleteRow($id){
    $serverName = "108.163.161.66";
    $connection = new mysqli($serverName, "f7103097_admin", "admin", "f7103097_lab_software");

    if($connection->connect_error){
        die("Connection to database unable to complete: ".$connection->connect_error);
    }

    try{
        $tableName=@$_GET['table'];
        $sql = "DELETE FROM $tableName WHERE id = $id";
        $connection->query($sql);
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }
    finally{
        $connection->close();
    }
}

if(@$_GET['run'] == "delete"){
    deleteRow($_GET['id']);
    header('Location: '.$_SERVER['PHP_SELF']);
    die;
}
?>