<head>
    <meta charset="UTF-8">
    <meta name="author", content="Entecott, Nicholas, Haberle, Ryan, Murphy, Patrick, Shaikh, Nehaal">
    <meta name="descripton" content="[placehold] is a website for managing George Brown College computer lab software.">
    <meta name="keywords" content="George Brown College, GBC, Computer Labs, Software">
    <title>Software Request</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="gbcCSS.css">

</head>
<body>

<header>
    <h1><a href="index.html">George Brown College</a></h1>
    <h2>Lab Software Repository/Software Request</h2>
    <div id="position-left">
        <form method="post" action="softwareRequest.php">
            <input type="submit" class="btn btn-primary" value="SOFTWARE REQUEST">
        </form>
        <form method="post" action="adminLogin.php">
            <input type="submit" class="btn btn-primary" value="ADMIN LOGIN">
        </form>
    </div>
    <div>
        <form method="post" action="softwareAvailable.php">
            <input type="submit" class="btn btn-primary" value="SOFTWARE AVALIABLE">
        </form>
        <form method="post" action="labRooms.php">
            <input type="submit" class="btn btn-primary" value="LAB ROOMS">
        </form>
    </div>
</header>
<hr>

<form method="GET" action="softwareRequest.php">
    What Lab is your request? <input type="text" name="labNum"><br><br>
    What Software requires installing? <input type="text" name="software"><br><br>
    What version of the software? <input type="text" name="version"><br><br>
    What is your computers unique ID?  <input type="text" name="reqID"><br><br>
    Comment: <input type="text" name="notes"><br><br>

    *Unique ID is found on back of the computer tower ex. C418IT46
    <br>
    <input type="submit" value="Send Request">
</form>

<?php
include 'userFunctions.php';
if(isset($_GET['labNum'])){
    addRequest(@$_GET['labNum'], @$_GET['software'], @$_GET['version'], @$_GET['reqID'], @$_GET['notes']);
}
?>

</body>
</html>


<?php
